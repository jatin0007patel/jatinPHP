<?php
session_start();
require_once("db.php");
$uname=$_POST['username'];
$psw=$_POST['pswd'];
$data=mysql_query("SELECT * FROM login_data where username='$uname' and password='$psw'");
$result=mysql_fetch_array($data);
$row=mysql_num_rows($data);
if($row==0)
{
	echo "<script type='text/javascript'>alert('Data Not Found')</script>";
	echo "<script type='text/javascript'>window.location.href = 'login.php'</script>";
}
else if($result['username']!=$uname || $result['password']!=$psw) 
{
	echo "<script type='text/javascript'>alert('Login Error...')</script>";
	echo "<script type='text/javascript'>window.location.href = 'login.php'</script>";
}
else
{
	$_SESSION['id']=$result['id'];
	header("location: home.php");
}
