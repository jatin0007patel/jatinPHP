<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>Politics | Login </title>
<meta charset="iso-8859-1">
<link rel="stylesheet" href="styles/layout.css" type="text/css">
<link rel="stylesheet" href="styles/form.css" type="text/css">
<link rel="stylesheet" href="styles/button.css" type="text/css">
<script type="text/javascript">
</script>

</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
      <h1><a href="index.html">Politics</a></h1>
      <h2>When We Play Game</h2>
    </div>
    <nav>
      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="login.php">Login</a></li>
		<li><a href="search.php">Search</a></li>
        <li class="last"><a href="registration.php">Registration</a></li>
      </ul>
    </nav>
  </header>
</div>
<div class="wrapper row2">
  <div id="container" class="clear">
    <div id="homepage">
	<br><br><br><br><br><br>
	 <div style="border-style:ridge; border-radius:6px; height:100%; width:100%;">
	  <form style="margin:20px;" name="request_form" method="post" action="check_login.php" autocomplete="off">
	  <table align="center">
	  <center><span style="font-family:Goudy Old Style;font-size:40px;">Login Form</span><hr></center>
	  <tr>
	  <td><input type="text" name="username" id="username" placeholder="Username" class="form-css" required></td>
	  </tr>
	  <tr>
	  <td><input type="password" name="pswd" placeholder="Password" class="form-css" required></td>
	  </tr>
	  <tr></tr> <tr></tr> <tr></tr> <tr></tr> <tr></tr> <tr></tr>
		<tr>
		<td colspan="3" align="center"><input type="submit" name="sbt" value="Go" class="myButton"></td></tr>
        </table>
		</form>
		</div>
    </div>
  </div>
  <br><br><br><br><br><br><br><br>
</div>
<div class="wrapper row3">
  <footer id="footer" class="clear">
    <p class="fl_left">Copyright &copy; 2017 - All Rights Reserved - <a href="#">Politics</a></p>
    <p class="fl_right">Design By VirusWeb.</a></p>
  </footer>
</div>
</body>
</html>
