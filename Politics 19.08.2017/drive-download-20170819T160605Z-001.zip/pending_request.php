<?php
session_start();
require_once("db.php");
if(!$_SESSION['id'])
{
		header("location: login.php");
}
else
{
	$id=$_SESSION['id'];
	$data=mysql_query("SELECT username FROM login_data where id=$id");
	$result=mysql_fetch_array($data);
	$name=$result['username'];
	$data2=mysql_query("select count(request) as total from candidate_reg where request=1");
	$result2=mysql_fetch_assoc($data2);
	$data3=mysql_query("select * from candidate_reg where request=1");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>Politics | Welcome </title>
<meta charset="iso-8859-1">
<link rel="stylesheet" href="styles/layout.css" type="text/css">
<link rel="stylesheet" href="styles/table.css" type="text/css">
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
      <h1><a href="index.html">Politics</a></h1>
      <h2>When We Play Game</h2>
    </div>
    <nav>
      <ul>
        <li><a href="home.php"><?php echo ucwords($name);?></a></li>
        <li><a href="pending_request.php">Request(<?php echo $result2['total']; ?>)</a></li>
        <li class="last"><a href="logout.php">logout</a></li>
      </ul>
    </nav>
  </header>
</div>
<div class="wrapper row2">
  <div id="container" class="clear">
    <div id="homepage">
	<table border="2" align="center" class="blueTable">
	<tr align="center">
	<th>ID</th>
	<th>Full Name</th>
	<th>Grant</th>
	<th>Revoke</th>
	</tr>
	<tr>
	<?php
	if($result2['total']==0)
	{
		echo "<td align='center' colspan='4'><b>No Pending Request</td>";
		echo "</tr>";
	}
	else
	{
		while($result3=mysql_fetch_array($data3))
		{
			echo "<td align='center'>$result3[membership_no]</td>";
			echo "<td align='center'>$result3[name]</td>";
			echo "<td align='center'><a href='approval.php?member=$result3[membership_no]&c=0'><p>Yes</p></a></td>";
			echo "<td align='center'><a href='approval.php?member=$result3[membership_no]&c=1'><p>Cancel Request</p></a></td>";
			echo "</tr>";
		}
	}
	?>
	</table>
    </div>
  </div>
</div>
<!-- Footer -->
<div class="wrapper row3">
  <footer id="footer" class="clear">
    <p class="fl_left">Copyright &copy; 2017 - All Rights Reserved - <a href="index.html">Politics</a></p>
    <p class="fl_right">Design By VirusWeb.</a></p>
  </footer>
</div>
</body>
</html>
