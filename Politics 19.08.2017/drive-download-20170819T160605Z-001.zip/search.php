<?php
require_once("db.php");
$result8=mysql_query("select * from candidate_reg where request=2");
$count=mysql_num_rows($result8);
$sr=0;
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>Politics | Result</title>
<meta charset="iso-8859-1">
<link rel="stylesheet" href="styles/layout.css" type="text/css">
<link rel="stylesheet" href="styles/table.css" type="text/css">
<link rel="stylesheet" href="styles/form.css" type="text/css">
<script language="Javascript" src="scripts/search.js"></script>
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
      <h1><a href="index.html">Politics</a></h1>
      <h2>When We Play Game</h2>
    </div>
    <nav>
      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="login.php">Login</a></li>
		<li><a href="search.php">Search</a></li>
        <li class="last"><a href="registration.php">Registration</a></li>
      </ul>
    </nav>
  </header>
</div>
<div class="wrapper row2">
  <div id="container" class="clear">
    <div id="homepage">
	<input type="text" class="form-css" id="myInput" onkeyup="myFunction()" placeholder="Search name" autocomplete="off"><br><br>
	<h1>All Member's List</h1><hr>
	<table border="2" align="center" class="blueTable" id="myTable">
	<tr align="center">
	<th>Sr No.</th>
	<th>Full Name</th>
	<th>Party Name</th>
	<th>View Profile</th>
	</tr>
	<tr>
	<?php
	if($count==0)
	{
		echo "<td align='center' colspan='4'><b>No Data Found</td>";
		echo "</tr>";
	}
	else
		while($data8=mysql_fetch_array($result8))
		{
			++$sr;
			echo "<td align='center'><b>$sr</b></td>";
			echo "<td align='center'><b>$data8[name]</b></td>";
			echo "<td align='center'>$data8[party_name]</td>";
			echo "<td align='center'><a href='member_profile.php?k=$data8[membership_no]'><p>View</p></a></td>";
			echo "</tr>";
		}
	?>
	</table>
    </div>
  </div>
</div>
<!-- Footer -->
<div class="wrapper row3">
  <footer id="footer" class="clear">
    <p class="fl_left">Copyright &copy; 2017 - All Rights Reserved - <a href="index.html">Politics</a></p>
    <p class="fl_right">Design By VirusWeb.</a></p>
  </footer>
</div>
</body>
</html>
