<?php
@ini_set('display_errors', 0);
require_once("db.php");
$uname=$_POST['username'];
$data=mysql_query("SELECT * FROM candidate_reg where membership_no=$uname");
$result=mysql_fetch_array($data);
$row=mysql_num_rows($data);
if($row==0)
{
	echo "<script type='text/javascript'>alert('No Candidate Available')</script>";
	echo "<script type='text/javascript'>window.location.href = 'registration.php'</script>";
}
else if($result[request]==1)
{
	echo "<script type='text/javascript'>alert('Already Sent a request')</script>";
	echo "<script type='text/javascript'>window.location.href = 'registration.php'</script>";
}
else if($result[request]==2)
{
	echo "<script type='text/javascript'>alert('Your Requeat is Aprooved')</script>";
	echo "<script type='text/javascript'>window.location.href = 'registration.php'</script>";
}
else
{
	mysql_query("UPDATE `candidate_reg` SET `request` = '1' WHERE `candidate_reg`.`membership_no` = $uname;");
	echo "<script type='text/javascript'>alert('Request Sent For Approoval...')</script>";
	echo "<script type='text/javascript'>window.location.href = 'registration.php'</script>";
}
?>