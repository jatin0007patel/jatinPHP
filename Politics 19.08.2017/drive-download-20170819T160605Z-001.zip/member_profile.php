
<?php
require_once("db.php");
$id=$_GET['k'];
$result=mysql_query("select * from candidate_basic_info where member_id=$id");
$count=mysql_num_rows($result);
$data=mysql_fetch_array($result);
if($count==0)
{
	echo "<script type='text/javascript'>alert('No Data Available')</script>";
	echo "<script type='text/javascript'>window.location.href = 'party_page.php'</script>";
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>Politics | Result</title>
<meta charset="iso-8859-1">
<link rel="stylesheet" href="styles/layout.css" type="text/css">
<link rel="stylesheet" href="styles/table.css" type="text/css">
<link rel="stylesheet" href="styles/form.css" type="text/css">
<script language="Javascript" src="scripts/search.js"></script>
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
      <h1><a href="index.html">Politics</a></h1>
      <h2>When We Play Game</h2>
    </div>
    <nav>
      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="login.php">Login</a></li>
		<li><a href="search.php">Search</a></li>
        <li class="last"><a href="registration.php">Registration</a></li>
      </ul>
    </nav>
  </header>
</div>
<div class="wrapper row2">
  <div id="container" class="clear">
  <h1>Member Profile</h1><hr>
    <div id="homepage"><br><br><br>
<table border="1" class="blueTable" style="font-size:20px;">
<tr>
<td rowspan="8" align="center"><?php echo '<img src="data:image/jpeg;base64,'.base64_encode($data['member_photo']).'" height="200px" width="150px"/>';?></td>  
</tr>
<tr>
<td><b>Name:</b> <?php echo $data['member_name']; ?></td> 
</tr>
<tr>
<?php $date=$data['member_join_date'];?>
<td><b>Joining From:</b> <?php echo date("d/m/Y",strtotime($date)); ?></td> 
</tr>
<tr>
<td><b>Experience:</b> 
<?php
$p=date("Y",strtotime($date));
$f=date("d/m/Y",strtotime($date));
$o=date("Y");
$r=$o-$p;
echo "$r Year(s)"; 
?>
</td> 
</tr>
<tr>
<td><b>Designation:</b> <?php echo $data['member_type']; ?></td> 
</tr>
<tr>
<td><b>Ward No.:</b> <?php echo $data['member_ward']; ?></td> 
</tr>
<tr>
<td><b>Education:</b> <?php echo $data['member_qualification']; ?></td> 
</tr>
<tr>
<td><b>Social Activity:</b> <?php echo $data['member_social_activity']; ?></td> 
</tr>
</table>
<br><br><br><br><br><br>
<hr>
    </div>
  </div>
</div>
<!-- Footer -->
<div class="wrapper row3">
  <footer id="footer" class="clear">
    <p class="fl_left">Copyright &copy; 2017 - All Rights Reserved - <a href="index.html">Politics</a></p>
    <p class="fl_right">Design By VirusWeb.</a></p>
  </footer>
</div>
</body>
</html>

</body>
</html>