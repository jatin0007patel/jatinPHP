<?php
session_start();
require_once("db.php");
if(!$_SESSION['id'])
{
		header("location: login.php");
}
else
{
	$m=$_GET['member'];
	$r=$_GET['c'];
	$result=mysql_query("SELECT * FROM `candidate_basic_info` where member_id=$m");
	$count=mysql_num_rows($result);
	if($count<1)
	{
		echo "<script type='text/javascript'>alert('Request Can't Grant Because No Basic Data Found')</script>";
		echo "<script type='text/javascript'>window.location.href = 'pending_request.php'</script>";
	}
	else if($r==0)
	{
		mysql_query("update candidate_reg set request=2 where membership_no=$m");
		echo "<script type='text/javascript'>alert('Request Granted')</script>";
		echo "<script type='text/javascript'>window.location.href = 'pending_request.php'</script>";
	}
	else if($r==1)
	{
		mysql_query("update candidate_reg set request=0 where membership_no=$m");
		echo "<script type='text/javascript'>alert('Request Revoke')</script>";
		echo "<script type='text/javascript'>window.location.href = 'pending_request.php'</script>";
	}
}
?>