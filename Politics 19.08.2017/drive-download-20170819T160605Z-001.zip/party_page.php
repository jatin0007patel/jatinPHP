<?php
require_once("db.php");
$id=mysql_real_escape_string($_GET['p']);
if($id=="")
{
	header("Location: index.html");
}
$data=mysql_query("select * from party_info where party_id=$id");
$count=mysql_num_rows($data);
if($count==0)
{
	header("Location: index.html");
}
else
{
	$result=mysql_fetch_array($data);
	$pname=$result['party_name'];
	$data2=mysql_query("select request,membership_no from candidate_reg where party_name='$pname'");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>Party Page | Politics</title>
<meta charset="iso-8859-1">
<link rel="stylesheet" href="styles/layout1.css" type="text/css">
<script language="Javascript" src="scripts/search.js"></script>
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
      <h1><a href="index.html">Politics</a></h1>
      <h2>When We Play Game</h2>
    </div>
	<img src="images/man.png" align="right" height="100px" width="100px">
    <nav>
      <ul>
		<li><a href="index.html">Home</a></li>
		<li>|</li>
        <li>Information About Party </li>
      </ul>
    </nav>
  </header>
</div>
<!-- content -->
<div class="wrapper row2">
  <div id="container" class="clear">
    <!-- Slider -->
    <section id="slider" class="clear">
      <figure><?php echo '<img src="data:image/jpeg;base64,'.base64_encode($result['party_image']).'"/>';?>
        <figcaption>
          <h2><?php echo $result['party_name'];?></h2><h6><?php echo $result['party_id'];?></h6>
          <p style="text-align:justify;"><?php echo $result['party_desc'];?></p>
		  <table>
		  <tr><td>President:</td><td><b><?php echo $result['party_president'];?></b></td>
		  <tr><td>Headquarters:</td><td><b><i><?php echo $result['party_hq'];?></i></b></td>
		  </table>
        </figcaption>
      </figure>
    </section>
    <!-- main content -->
	<h1>Member's List</h1><br>
	<hr>
    <div id="intro">
      <section class="clear">
        <article class="two_quarter lastbox">
          <figure>
            <ul class="clear">
              <li>
			  <table id="myTable">
			  <tr>
			  <?php
			  while($result2=mysql_fetch_array($data2))
			  {
					if($result2['request']==2)
					{
						$data3=mysql_query("select member_name,member_photo from candidate_basic_info where member_id=$result2[membership_no]");
						while($result3=mysql_fetch_array($data3))
						{
							echo"<td align='center'>";
							echo '<img src="data:image/jpeg;base64,'.base64_encode($result3['member_photo']).'"/>';
							echo"<a href=member_profile.php?k=$result2[membership_no]><figcaption><b>|</b>$result3[member_name]</figcaption></a>";
							echo"</td></a>";
						}
					}
			  }
			  ?>
			  </tr>
			  </table>
			  </ul>
           
          </figure>
        </article>
      </section>
    </div>
    <div id="homepage" class="last clear">
    </div>
    <!-- / content body -->
  </div>
</div>
<!-- Footer -->
<div class="wrapper row3">
  <footer id="footer" class="clear">
     <p class="fl_left">Copyright &copy; 2017 - All Rights Reserved - <a href="index.html">Politics</a></p>
    <p class="fl_right">Design By VirusWeb.</a></p>
  </footer>
</div>
</body>
</html>
